BOT TELEGRAM MUSICAL V2 - DEPLOIEMENT RENDER

1) Fichiers
- bot_telegram_music_v2.py : code principal
- requirements_music_bot.txt : dépendances Python

2) Variables d'environnement Render
BOT_TOKEN = le nouveau token créé via BotFather
MUSICBRAINZ_USER_AGENT = TelegramMusicBot/2.0 (email@exemple.com)
MAX_CONCURRENT_DOWNLOADS = 2
MAX_ALBUMS = 5
MAX_ALBUM_TRACKS = 25
PORT = Render le fournit automatiquement

NE METS JAMAIS BOT_TOKEN DIRECTEMENT DANS LE CODE OU GITHUB.

3) Commandes
/start
/help
/albums Artiste

Compatibilité conservée :
- "album Artiste"
- "albums Artiste"
- simple titre/artiste
- URL directe

4) Dépendances système
Le projet utilise imageio-ffmpeg pour disposer d'un binaire ffmpeg via Python. yt-dlp est installé avec ses dépendances [default,deno], notamment yt-dlp-ejs.

5) Render
Le service actuel peut rester un Web Service pour conserver le serveur Flask /healthz.
Attention : un Web Service gratuit Render peut s'arrêter après 15 minutes sans trafic entrant. Le code Flask ne peut pas empêcher cela à lui seul. Pour une disponibilité permanente, utiliser un plan qui reste actif ou une architecture adaptée (worker/queue).

6) Données
Les noms/historiques sont en mémoire et seront réinitialisés lors d'un redémarrage. Pour une persistance réelle, utiliser une base de données.

7) Médias
Le code envoie l'audio sous M4A et refuse les fichiers au-dessus de 50 Mo pour éviter un échec côté Telegram.
Utiliser le téléchargement uniquement pour les contenus que tu as le droit de récupérer.
